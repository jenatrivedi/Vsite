import React, { Component } from "react";
import "./style.css";
//import "./icon-moon.css";



class ChangePasswordEdit extends Component {
    render() {
      return (
         <section class="content-wapper">
           <div class="breadcrumb">
             <ul>
               <li><button>Profile</button></li>
               <li>Change Password</li>
             </ul>
           </div>
           <div class="common-panel">
             <div class="panel-head"><div class="title">Admin Profile</div></div>
             <div class="panel-body admin-profile">
               <div class="vrow">
                 <div class="vcol-4">
                   <div class="form-group">
                     <label>New Password *</label>
                     <input class="form-control" type="password" name="" value="currentpassword"  />
                   </div>
                 </div> 
                 <div class="vcol-4">
                   <div class="form-group">
                     <label>Re-enter new password *</label>
                     <input class="form-control" type="password" name="" value="currentpassword"  />
                   </div>
                 </div>
               </div> 
             </div>
             <div class="panel-footer"><button class="blue-btn">Change</button></div>
           </div>
         </section>
   );
}
}

export default ChangePasswordEdit;