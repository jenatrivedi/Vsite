import React, { Component } from "react";

import img1 from "../../images/logo.png";
import img2 from "../../images/v-logo.png";
import {
  BrowserRouter as Router,
  Switch,
  Route,
  Link
} from "react-router-dom";





class Home extends Component {
  render() {
    return (
      <Router>
      <section class="site-wapper">
        <nav class="site-nav open">
          <div class="inner-nav">
            <div class="company-logo">
              <div class="pic">
                <img src={img1} class="on-open" alt="logo" />{" "}
                <img src={img2} class="on-close" alt="logo" />
              </div>
            </div>
            <div class="profile">
              <span class="pic">
                <i class="icon-user-management"></i>
              </span>
              <span class="name">Mark Zuckerberg</span>
            </div>

            <ul class="menu-list">
              <li>
                <button>
                  <span class="icn-img">
                    <i class="icon-user"></i>
                  </span>
                  <span class="text">User Management</span>
                </button>
              </li>
              <li>
                <button>
                  <span class="icn-img">
                    <i class="icon-lander-management"></i>
                  </span>
                  <span class="text">Lender Management</span>
                </button>
              </li>
              <li>
                <button>
                  <span class="icn-img">
                    <i class="icon-call-configuration"></i>
                  </span>
                  <span class="text">Call Configuration</span>
                </button>
              </li>
              <li class="active">
                <button>
                  <span class="icn-img">
                    <i class="icon-profile-settings"></i>
                  </span>
                  <span class="text">Profile</span>
                </button>
              </li>
            </ul>
          </div>
          <div class="sign-out">
            <button>
              <i class="icon-signout"></i>
              <div class="sign-out-text">Sign Out</div>
            </button>
          </div>
        </nav>
        <main class="site-content">
          <header class="top-header">
            <div class="toggle-icon">
              <button>
                <i class="icon-hamburger-menu"></i>
              </button>
            </div>
          </header>
          {this.props.children}
          </main>
          </section>
      </Router>
    );
  }
}

export default Home;
