import React, { Component } from "react";
import "./style.css";
//import "./icon-moon.css";
import {
    BrowserRouter as Router,
    Switch,
    Route,
    Link
  } from "react-router-dom";



class ChangePassword extends Component {
    state = {
        password: ''
      }

      handleChange = e => {
        this.setState({ [e.target.name]: e.target.value })
      }

    render() {

      return (

            <section class="content-wapper">
                <div class="breadcrumb">
                    <ul>
                        <li><button>Profile</button></li>
                        <li>Change Password</li>
                    </ul>
                </div>
                <div class="common-panel">
                    <div class="panel-head">
                        <div class="title">Admin Profile</div>
                    </div>
                    <div class="panel-body admin-profile">
                        <div class="vrow">
                            <div class="vcol-4">
                                <div class="form-group">
                                    <label>Current Password *</label>
                                    <input class="form-control" type="password" name="password" value={this.password} onChange={this.handleChange}/>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="panel-footer">
                    <Link to ="./change-password2">                     
                        <button class="blue-btn">Submit
                        </button>
                    </Link>
                    </div>
                </div>
                
            </section>
           
    );
}
}

export default ChangePassword;



